# E4/e7 contrast attempt 02 — interrupted tail

This online attempt used the frozen preregistration and canonical payloads but
launched with `TREE_DX_DIRECT_POST_OUTPUT_CAP=2048`.  It reached 375 completed
future results with zero schema failures before a small tail repeatedly hit
length/180-second transport limits.  The controlling PTY then terminated
before the runner could assemble `case_results.jsonl`.

The immutable cache directory was retained in the active arm directory.  It
contains 400 semantic cache records and is reused by the resumed execution;
completed cases are therefore not resampled.  The 396 telemetry records that
had been flushed before interruption are preserved beside this note.  This is
a runtime incident, not an experimental condition or a clinical endpoint.
